variable "file_name" {
  description = "Name of file to create"
  type        = string
}

variable "file_content" {
  description = "Content of file"
  type        = string
}