# Terraform Infrastructure Provisioning Demo

## Objective

Provision a simple resource using Terraform.

## Resource Created

A local file is created using Terraform's local provider.

## Files

* main.tf
* variables.tf
* outputs.tf
* terraform.tfvars

## Initialize Terraform

terraform init

## Validate Configuration

terraform validate

## Generate Execution Plan

terraform plan

## Apply Configuration

terraform apply

Type:

yes

when prompted.

## View Outputs

terraform output

## Destroy Resources

terraform destroy

## Terraform State

Terraform stores infrastructure state in:

terraform.tfstate

This file tracks resources created by Terraform and helps detect changes.

## Variables

Variables are defined in variables.tf and assigned values through terraform.tfvars.

## Output

The configuration creates a file named:

demo.txt

with the content:

Hello from Terraform!


Commands to Run
terraform init
terraform validate
terraform plan
terraform apply
terraform output
terraform destroy