file_name    = "demo.txt"
file_content = "Hello from Terraform!"